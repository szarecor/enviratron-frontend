/**
 * Created by szarecor on 6/7/17.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by szarecor on 6/7/17.
 */
var core_1 = require("@angular/core");
var ChamberButtonsComponent = (function () {
    function ChamberButtonsComponent() {
        this.chamberNames = [];
        this.selectedChambers = [];
        // Emit an event for the parent to handle when there is a change to the currently selected chambers:
        this.onChambersChange = new core_1.EventEmitter();
        /*
        @Input() dayCount: number = 0;
        @Input() selectedDays: any[] = [];
        @Input() completedDays: any[] = [];
        // to be populated by ngOnInit() method:
        days: any =  [];
    
        // Emit an event for the parent to handle when there is a change on the days <select> list:
        @Output() onDaysChange: EventEmitter<any> = new EventEmitter<any>();
    
        // This is fired when there is a change on the days <select> list, see the template for (ngModelChange)
        selectedDaysChangeHandler(selectedDays) {
            this.onDaysChange.emit(selectedDays);
        }
    
        ngOnInit() {
            // Initialize the array of day identifiers:
            this.days = Array.from(
                Array(this.dayCount).keys(),
                function(i) {
                    return i+1;
                }
            );
    
        }
        */
    }
    // This is fired when there is a change on the days <select> list, see the template for (ngModelChange)
    ChamberButtonsComponent.prototype.selectedChambersChangeHandler = function (selectedChambers) {
        this.onChambersChange.emit(selectedChambers);
    };
    ChamberButtonsComponent.prototype.chamberButtonClick = function (v) {
        if (this.selectedChambers.indexOf(v) === -1) {
            // Here we are adding a chamber to the selectedChambers []:
            this.selectedChambers.push(v);
        }
        else {
            // And here we are removing a chamber from the selectedChambers []:
            this.selectedChambers = this.selectedChambers.filter(function (oldVal) {
                return oldVal !== v;
            });
        }
        // emit the new data to the parent
        this.selectedChambersChangeHandler(this.selectedChambers);
    };
    ChamberButtonsComponent.prototype.allChambersButtonClick = function (ev) {
        this.selectedChambers = (this.selectedChambers.length === this.chamberNames.length) ? [] : this.chamberNames;
        // emit the new data to the parent
        this.selectedChambersChangeHandler(this.selectedChambers);
    };
    return ChamberButtonsComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], ChamberButtonsComponent.prototype, "chamberNames", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], ChamberButtonsComponent.prototype, "selectedChambers", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ChamberButtonsComponent.prototype, "onChambersChange", void 0);
ChamberButtonsComponent = __decorate([
    core_1.Component({
        selector: 'chamber-buttons',
        // This was poorly documented and difficult to find:
        interpolation: ['[[', ']]'],
        templateUrl: './chamber_buttons_template.html'
    })
], ChamberButtonsComponent);
exports.ChamberButtonsComponent = ChamberButtonsComponent;
//# sourceMappingURL=ChamberSelectButtons.component.js.map