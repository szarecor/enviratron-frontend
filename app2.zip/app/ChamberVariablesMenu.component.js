/**
 * Created by szarecor on 6/8/17.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by szarecor on 6/7/17.
 */
var core_1 = require("@angular/core");
var ChamberVariablesMenuComponent = (function () {
    function ChamberVariablesMenuComponent() {
        this.currentState = "Lighting";
        // Emit an event for the parent to handle when there is a change on the days <select> list:
        this.onStateChange = new core_1.EventEmitter();
        this.menuItems = ['Lighting', 'Temperature', 'Watering', 'Humidity', 'CO2'];
    }
    ChamberVariablesMenuComponent.prototype.handleClick = function (newState) {
        this.currentState = newState;
        // emit the the new value to the parent component:
        this.onStateChange.emit(this.currentState);
    };
    return ChamberVariablesMenuComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ChamberVariablesMenuComponent.prototype, "currentState", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ChamberVariablesMenuComponent.prototype, "foobar", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ChamberVariablesMenuComponent.prototype, "onStateChange", void 0);
ChamberVariablesMenuComponent = __decorate([
    core_1.Component({
        selector: 'chamber-variables-menu',
        // This was poorly documented and difficult to find:
        interpolation: ['[[', ']]'],
        templateUrl: './chamber_variables_menu_template.html'
    })
], ChamberVariablesMenuComponent);
exports.ChamberVariablesMenuComponent = ChamberVariablesMenuComponent;
//# sourceMappingURL=ChamberVariablesMenu.component.js.map