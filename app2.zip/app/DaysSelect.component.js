"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by szarecor on 6/7/17.
 */
var core_1 = require("@angular/core");
var DaysSelectComponent = (function () {
    function DaysSelectComponent() {
        this.dayCount = 0;
        this.selectedDays = [];
        this.completedDays = [];
        // to be populated by ngOnInit() method:
        this.days = [];
        // Emit an event for the parent to handle when there is a change on the days <select> list:
        this.onDaysChange = new core_1.EventEmitter();
    }
    // This is fired when there is a change on the days <select> list, see the template for (ngModelChange)
    DaysSelectComponent.prototype.selectedDaysChangeHandler = function (selectedDays) {
        this.onDaysChange.emit(selectedDays);
    };
    DaysSelectComponent.prototype.ngOnInit = function () {
        // Initialize the array of day identifiers:
        this.days = Array.from(Array(this.dayCount).keys(), function (i) {
            return i + 1;
        });
    };
    return DaysSelectComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], DaysSelectComponent.prototype, "dayCount", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], DaysSelectComponent.prototype, "selectedDays", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], DaysSelectComponent.prototype, "completedDays", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], DaysSelectComponent.prototype, "onDaysChange", void 0);
DaysSelectComponent = __decorate([
    core_1.Component({
        selector: 'days-select',
        // This was poorly documented and difficult to find:
        interpolation: ['[[', ']]'],
        templateUrl: './days_select_template.html'
    })
], DaysSelectComponent);
exports.DaysSelectComponent = DaysSelectComponent;
//# sourceMappingURL=DaysSelect.component.js.map