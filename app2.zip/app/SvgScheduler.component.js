"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by szarecor on 6/8/17.
 */
var core_1 = require("@angular/core");
var SvgSchedulerComponent = (function () {
    function SvgSchedulerComponent() {
        this.dayCount = 0;
        this.margin = { top: 20, right: 20, bottom: 40, left: 20 };
        //g : any;
        this.timePoints = [];
        this.circleAttrs = {
            cx: function (d) { return xScale(d.x); },
            cy: function (d) { return yScale(d.y); },
            r: 6
        };
        this.startDate = new Date();
        this.endDate = new Date();
        // Emit an event for the parent to handle when there is a change on the days <select> list:
        this.onDaysChange = new core_1.EventEmitter();
        /*
      
      
          // Begin the SVG:
          var svg = d3.select("svg"),
            margin = {top: 20, right: 20, bottom: 40, left: 20},
            width = +svg.attr("width") - margin.left - margin.right,
            height = +svg.attr("height") - margin.top - margin.bottom,
            g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
      
      
          var timePoints = [];
          var circleAttrs = {
            cx: function(d) { return xScale(d.x); },
            cy: function(d) { return yScale(d.y); },
            r: 6
          };
      
          var startDate = new Date();
          startDate.setHours(0, 0, 0);
          var endDate = new Date();
          endDate.setHours(23, 59, 00);
      
          var xScale = d3.scaleTime()
            .domain([startDate, endDate])
            .range([0, width]);
      
          console.log(xScale)
      
          //xScale.ticks(d3.timeMinute.every(10));
      
      
          var yScale = d3.scaleLinear()
            .domain([0, 40])
            .range([height, 0]);
      
          g.append("g")
            .attr("transform", "translate(0," + height + ")")
            .attr("class", "grid")
            .call(
              d3.axisBottom(xScale)
                .ticks(d3.timeMinute.every(30))
                .tickSize(-height)
            )
            .selectAll("text")
            .attr("y", 0)
            .attr("x", -5)
            .attr("dy", ".35em")
            .attr("transform", "rotate(-90)")
            .style("text-anchor", "end")
            .style("display", function(d,i) { return i % 2 === 0 ? "none" : "inherit" })
      
          g.append("g")
            .call(
              d3.axisLeft(yScale)
              //.ticks(d3.timeMinute.every(30))
                .tickSize(-width)
            )
            .attr("class", "grid")
            .append("text")
            .attr("fill", "#000")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", "0.71em")
            .attr("text-anchor", "end")
            .text("Celcius");
      
      
          // Let's track the mouse position!:
          svg.on(
            "mousemove"
            , function() {
      
              var rawCoords = d3.mouse(this);
      
              // Normally we go from data to pixels, but here we're doing pixels to data
              var newPoint = {
                x: Math.round(xScale.invert(rawCoords[0] - margin.left)),
                y: Math.round(yScale.invert(rawCoords[1] - margin.top))
              }
                , timeString = new Date(newPoint.x).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
      
      
              console.log(timeString)
      
              currentMouseTemp = newPoint.y;
              currentMouseTime = timeString;
      
      
              if (rawCoords[0] <= margin.left || rawCoords[0] >= margin.left + width) {
                currentMouseTemp = '';
                currentMouseTime = '';
              }
      
              if (rawCoords[1] <= margin.top || rawCoords[1] >= margin.top + height) {
                currentMouseTemp = '';
                currentMouseTime = '';
              }
      
      
              document.getElementById("mouseCurrentTemp").innerHTML = currentMouseTemp;
              document.getElementById("mouseCurrentTime").innerHTML = currentMouseTime;
      
            }
      
          )
      
      
          // On Click, we want to add data to the array and chart
          svg.on("click", function() {
      
            var coords = d3.mouse(this);
      
            // Make sure we don't draw any points outside of the graph area:
            if (coords[0] <= margin.left || coords[0] >= margin.left + width) {
              return;
            }
      
            if (coords[1] <= margin.top || coords[1] >= margin.top + height) {
              return;
            }
      
            // Normally we go from data to pixels, but here we're doing pixels to data
            var newPoint = {
              x: Math.round(xScale.invert(coords[0] - margin.left)),
              y: Math.round(yScale.invert(coords[1] - margin.top))
            }
              , timeString = new Date(newPoint.x).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
      
      
            // We need to remove the first and last synthetic points before adding our new point:
            timePoints.pop()
            timePoints.splice(0, 1);
      
            timePoints.push({
              x: coords[0]
              , y: coords[1]
              , temp: newPoint.y
              , time: timeString
      
            })
      
      
            updateRendered();
      
          })
      
      
          var line = d3.line()
            .x(function(d) { return d.x; })
            .y(function(d) { return d.y; })
            .curve(d3.curveLinear);
          //d3.curveStepAfter);
      
      
          function updateRendered() {
      
            var mySelection = svg.selectAll("circle")
              .data(
                timePoints,
                // tell d3 to bind to a property of the obj and not simply it's array pos:
                function(d,i) { return d.time; }
              );
      
            mySelection
              .enter()
              .append("circle")
              .attr("cx", function(d) { return d.x; })
              .attr("cy", function(d) { return d.y; })
              .attr("r", 5)
              .style("stroke", "steelblue")
              .style("stroke-width", 2)
              .attr("data-celcius", function(d) { return d.temp; })
              .attr("data-time", function(d) { return d.time; })
              .classed("time-series-marker", true)
              .on(
                "click",
                function(p) {
                  timePointClick(p);
                }
              )
      
            mySelection
              .exit()
              .remove();
      
      
            svg.selectAll("path")
              .data([])
              .exit()
              .remove();
      
      
            // Sort the timepoints by time before rendering:
            timePoints.sort(function(a,b) {
              if (a === b) {
                return 0;
              } else {
                return a.x < b.x ? -1 : 1;
              }
      
            });
      
            // Now make sure that the entire 24 hours are covered:
      
            // Create a point for 12:01 AM:
            if (timePoints[0].x > 0) {
              timePoints.splice(
                0,
                0,
                {
                  x: 0
                  , y: timePoints[0].y
                  , temp: timePoints[0].temp
                  , time: new Date(0).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                }
              )
            }
      
            // And create a point to cover to the right end (midnight):
            if (timePoints[timePoints.length-1].time !== '12:00 AM') {
      
              var lastTimePoint = timePoints[timePoints.length-1]
      
              console.log("need to add a terminal")
      
              timePoints.push({
                x: width
                , y: lastTimePoint.y
                , temp: lastTimePoint.temp
                , time: new Date(width).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
              });
            }
      
            //console.log(timePoints); //.map(function(p) { return p.x; }))
      
            svg.append("path")
              .datum(timePoints)
              .attr("fill", "none")
              .attr("stroke", "steelblue")
              .attr("stroke-linejoin", "round")
              .attr("stroke-linecap", "round")
              .attr("stroke-width", 1.5)
              .attr("d", line);
      
      
            var tbl = d3.select("table tbody");
            //console.log(tbl)
      
            // Clear any existing table rows:
            tbl.selectAll("tr")
              .data([])
              .exit()
              .remove();
      
            // Render table rows:
            var rows = tbl.selectAll("tr")
              .data(timePoints)
              .enter()
              .append("tr");
      
      
            // create a cell in each row for each column
            var cells = rows.selectAll("td")
              .data(function(row) {
                return [row.time, row.temp];
              })
              .enter()
              .append("td")
              .html(function(d) { return d; });
      
          } // updateRendered()
      
      
      
          function timePointClick(thisPoint) {
            //console.log(thisPoint);
            console.log(timePoints);
      
            timePoints = timePoints.filter(function(p) {
      
              return !(p.x === thisPoint.x && p.y === thisPoint.y);
      
            });
      
            //console.log(timePoints);
      
            updateRendered();
            d3.event.stopPropagation();
          }
      
        //}
      */
    }
    // This is fired when there is a change on the days <select> list, see the template for (ngModelChange)
    SvgSchedulerComponent.prototype.selectedDaysChangeHandler = function (selectedDays) {
        this.onDaysChange.emit(selectedDays);
    };
    SvgSchedulerComponent.prototype.ngOnInit = function () {
        this.endDate.setHours(23, 59, 0);
        this.startDate.setHours(0, 0, 0);
        this.experimentDaysArray = d3.range(0, 1 + this.dayCount);
        this.svg = d3.select('svg');
        var margin = this.margin;
        var svg = this.svg;
        this.width = +svg.attr("width") - margin.left - margin.right;
        this.height = +svg.attr("height") - margin.top - margin.bottom;
        var g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        this.xScale = d3.scaleTime()
            .domain([this.startDate, this.endDate])
            .range([0, this.width]);
        this.yScale = d3.scaleLinear().domain([0, 40]).range([this.height, 0]);
        var g2 = g.append("g")
            .attr("transform", "translate(0," + this.height + ")")
            .attr("class", "grid")
            .call(d3.axisBottom(this.xScale)
            .ticks(d3.timeMinute.every(30))
            .tickSize(-this.height));
        ;
        g2.selectAll("text")
            .attr("y", 0)
            .attr("x", -5)
            .attr("dy", ".35em")
            .attr("transform", "rotate(-90)")
            .style("text-anchor", "end")
            .style("display", function (d, i) { return i % 2 === 0 ? "none" : "inherit"; });
        var g3 = g.append("g")
            .call(d3.axisLeft(this.yScale)
            .tickSize(-this.width));
        ;
        g3.attr("class", "grid")
            .append("text")
            .attr("fill", "#000")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", "0.71em")
            .attr("text-anchor", "end")
            .text("Celcius");
        var _this = this; //.svg;
        var _xScale = this.xScale;
        var _yScale = this.yScale;
        // Let's track the mouse position!:
        this.svg.on("mousemove", function () {
            var rawCoords = d3.mouse(this);
            // Normally we go from data to pixels, but here we're doing pixels to data
            var newPoint = {
                x: Math.round(_xScale.invert(rawCoords[0] - margin.left)),
                y: Math.round(_yScale.invert(rawCoords[1] - margin.top))
            }, timeString = new Date(newPoint.x).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            var currentMouseTemp = newPoint.y;
            var currentMouseTime = timeString;
            if (rawCoords[0] <= margin.left || rawCoords[0] >= margin.left + this.width) {
                currentMouseTemp = '';
                currentMouseTime = '';
            }
            if (rawCoords[1] <= margin.top || rawCoords[1] >= margin.top + this.height) {
                currentMouseTemp = '';
                currentMouseTime = '';
            }
        });
        // On Click, we want to add data to the array and chart
        this.svg.on("click", function () {
            var coords = d3.mouse(this);
            // Make sure we don't draw any points outside of the graph area:
            if (coords[0] <= margin.left || coords[0] >= margin.left + this.width) {
                return;
            }
            if (coords[1] <= margin.top || coords[1] >= margin.top + this.height) {
                return;
            }
            // Normally we go from data to pixels, but here we're doing pixels to data
            var newPoint = {
                x: Math.round(_xScale.invert(coords[0] - margin.left)),
                y: Math.round(_yScale.invert(coords[1] - margin.top))
            }, timeString = new Date(newPoint.x).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            // We need to remove the first and last synthetic points before adding our new point:
            //_this.timePoints.pop()
            //_this.timePoints.splice(0, 1);
            _this.timePoints.push({
                x: coords[0],
                y: coords[1],
                temp: newPoint.y,
                time: timeString
            });
            console.log(_this.timePoints);
            updateRendered(_this.timePoints);
        });
        function updateRendered(timePoints) {
            var mySelection = svg.selectAll("circle")
                .data(timePoints, 
            // tell d3 to bind to a property of the obj and not simply it's array pos:
            function (d, i) { return d.time; });
            mySelection
                .enter()
                .append("circle")
                .attr("cx", function (d) { return d.x; })
                .attr("cy", function (d) { return d.y; })
                .attr("r", 5)
                .style("stroke", "steelblue")
                .style("stroke-width", 2)
                .attr("data-celcius", function (d) { return d.temp; })
                .attr("data-time", function (d) { return d.time; })
                .classed("time-series-marker", true)
                .on("click", function (p) {
                timePointClick(p);
            });
            mySelection
                .exit()
                .remove();
            svg.selectAll("path")
                .data([])
                .exit()
                .remove();
            // Sort the timepoints by time before rendering:
            timePoints.sort(function (a, b) {
                if (a === b) {
                    return 0;
                }
                else {
                    return a.x < b.x ? -1 : 1;
                }
            });
            // Now make sure that the entire 24 hours are covered:
            // Create a point for 12:01 AM:
            if (timePoints[0].x > 0) {
                timePoints.splice(0, 0, {
                    x: 0,
                    y: timePoints[0].y,
                    temp: timePoints[0].temp,
                    time: new Date(0).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                });
            }
            // And create a point to cover to the right end (midnight):
            if (timePoints[timePoints.length - 1].time !== '12:00 AM') {
                var lastTimePoint = timePoints[timePoints.length - 1];
                console.log("need to add a terminal");
                timePoints.push({
                    x: width,
                    y: lastTimePoint.y,
                    temp: lastTimePoint.temp,
                    time: new Date(width).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                });
            }
            //console.log(timePoints); //.map(function(p) { return p.x; }))
            svg.append("path")
                .datum(timePoints)
                .attr("fill", "none")
                .attr("stroke", "steelblue")
                .attr("stroke-linejoin", "round")
                .attr("stroke-linecap", "round")
                .attr("stroke-width", 1.5)
                .attr("d", line);
            var tbl = d3.select("table tbody");
            //console.log(tbl)
            // Clear any existing table rows:
            tbl.selectAll("tr")
                .data([])
                .exit()
                .remove();
            // Render table rows:
            var rows = tbl.selectAll("tr")
                .data(timePoints)
                .enter()
                .append("tr");
            // create a cell in each row for each column
            var cells = rows.selectAll("td")
                .data(function (row) {
                return [row.time, row.temp];
            })
                .enter()
                .append("td")
                .html(function (d) { return d; });
        } // updateRendered()
    };
    return SvgSchedulerComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], SvgSchedulerComponent.prototype, "dayCount", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], SvgSchedulerComponent.prototype, "onDaysChange", void 0);
SvgSchedulerComponent = __decorate([
    core_1.Component({
        selector: 'svg-scheduler',
        // This was poorly documented and difficult to find:
        interpolation: ['[[', ']]'],
        templateUrl: './svg_scheduler_template.html'
    })
], SvgSchedulerComponent);
exports.SvgSchedulerComponent = SvgSchedulerComponent;
//# sourceMappingURL=SvgScheduler.component.js.map