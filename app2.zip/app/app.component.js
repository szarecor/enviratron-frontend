"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        /*
        name: string = 'World';
        values: string = 'foobar';
        */
        this.currentChambers = [];
        this.currentDays = [];
        /*
        chamberRegimes: = {
          'chambers': {
              'chamber 1': {
                  'temperature': {
                      // k == datetime, v == degrees celsius
    
                  }
    
    
              }
    
            }
    
    
    
        };
        */
        this.chambers = ['chamber 1', 'chamber 2', 'chamber 3', 'chamber 4', 'chamber 5', 'chamber 6', 'chamber 7', 'chamber 8'];
        this.dayCount = 20;
        this.selectedDays = [1, 5, 6, 7];
        this.completedDays = [2, 3, 4];
    }
    AppComponent.prototype.handleDaysChange = function (e) {
        this.currentDays = e;
    };
    AppComponent.prototype.handleChambersChange = function (e) {
        this.currentChambers = e;
    };
    AppComponent.prototype.handleChamberVariablesMenuStateChange = function (newState) {
        this.currentChamberVariable = newState;
    };
    AppComponent.prototype.onClickMe = function () {
        console.log("click", this);
        this.values = '';
        //this.valuesChange.emit(this.values);
        //this.textBox.nativeElement.value = '';
    };
    ;
    AppComponent.prototype.onKey = function (value) {
        //this.values = value; //event.target.value;
        return;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        // This was poorly documented and difficult to find:
        interpolation: ['[[', ']]'],
        templateUrl: './app_template.html'
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map